#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"


int MAX_CONTACT = 100;


void listContacts(AddressBook *addressBook) 
{
    if(addressBook->contactCount == 0)
    {
        printf(RED "\n No contacts in the contact list \n" RESET);
    }
    if(addressBook->contactCount)
    {
      printf("\n***************** "BLUE"Welcom to contact List %d "RESET"  *******************\n", addressBook->contactCount); 
            
            
        for(int i = 0; i < addressBook->contactCount; i++)
        {
           
            printf( " %-20s\t", addressBook->contacts[i].name  );
            printf( " %-20s\t", addressBook->contacts[i].phone );
            printf( " %-20s\n", addressBook->contacts[i].email );
        }
    }
    
}

void initialize(AddressBook *addressBook)
 {
    addressBook->contactCount = 0;
    
    FILE *fptr = fopen("contacts.txt", "r");
    if(fptr == NULL)
    {
        printf("File doesn't exist\n");
        return;
    }

   fscanf(fptr, "#%d\n", &addressBook->contactCount);
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        fscanf(fptr, "%[^,],%[^,],%[^\n]\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);

    }
    fclose(fptr);
}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

int validate_name(char *str)
{
    for(int i = 0; str[i] != '\0'; i++)
    {
        if(!isalpha ((unsigned char) str[i]) && str[i] != ' ' && str[i] != '\\')
            {
                printf(RED "not matched\n" RESET);
                return 1;
            }
    }
        return 0;
}
int validate_number(char *str)
{
    for(int i = 0; str[i] != '\0'; i++)
    {
        if(!isdigit((unsigned char)str[i]))
        {
            return 1;
        }   
    }
    return 0;
}
int validate_email(char *str)
{
    char ch[10] = "@";
    char dot[10] = ".com";
    char *a = strstr(str, ch);
    char *b = strstr(str, dot);
    int len = strlen(str);

    if(a == NULL || b == NULL)
    {
        return 1;
    }
    else if((b - a) <= 1)
    {
        return 1;
    }
    else if(!(str[0] != ' ' && str[0] != '\\' && str[0] != '@'))
    {
        return 1;
    }
    else if(strstr(str, "@@") != NULL)
    {
        return 1;
    }
    else if(strstr(str, ".com.com") != NULL)
    {
        return 1;
    }
    else if(strstr(str, "..") != NULL)
    {
        return 1;
    }
    else
      return 0;
}

void createContact(AddressBook *addressBook)
{
     char temp[50];
     char number[12];
     char email[50];
     int res = 0;
     int contactCount = 0;
     int dup = 0;
     
   
    if(addressBook->contactCount >= MAX_CONTACTS)
    {
        printf(YELLOW "\nYou have reached the maxmium contacts!\n" RESET);
        return;
    }
    
   {
        do
       {
            printf("Enter name: ");
            scanf(" %[^\n]", temp);
            res = validate_name(temp);
            if(res == 1)
            {
                printf(RED "Plese enter valid input!!\n" RESET);
            }
       }while(res == 1); 
    }
 {  
    do
    {
        dup = 0;
        printf("Enter Mobile : ");
        scanf(" %11[^\n]", number);
        res = validate_number(number);
        if(res == 1 || strlen(number) != 10)
        {
            printf(RED "plese Enter valid number!\n" RESET );
        }
        for(int i = 0; i < addressBook->contactCount; i++)
        {
            if(strcmp(addressBook->contacts[i].phone, number) == 0)     // Rejects if number already exits.
            {
                printf(YELLOW "This number is already exists, enter another number.\n" RESET);
                dup = 1;
                res =1;
                break;
            }
        }
        if(dup == 1)
        {
            continue;
        }
    }while(res == 1 || strlen(number) != 10);
 }
 {
        do
        {
            printf("Enter Email : ");
            scanf(" %49s", email);
            res = validate_email(email);
            if(res == 1)
            {
                printf(RED "Enter valid email!\n" RESET);
            }
           for(int i = 0; i < addressBook->contactCount; i++)
           {
                if(strcmp(addressBook->contacts[i].email, email) == 0)
                {
                    printf(YELLOW "This email is already exists, enter another email.\n" RESET);
                    dup = 1;
                    res = 1;
                    break;
                }
           }
           if(dup == 1)
           {
            continue;
           }
        }while(res == 1);

   printf("%s\n", temp);
   printf("%s\n", number);
   printf("%s\n", email);


    strcpy(addressBook->contacts[addressBook->contactCount].name, temp);
    strcpy(addressBook->contacts[addressBook->contactCount].phone, number);
    strcpy(addressBook->contacts[addressBook->contactCount].email, email);

    printf(GREEN "Contact Saved successfully!!\n" RESET);

   
 }
 addressBook->contactCount++;    // increments the count after successful save
}
int searchContact(AddressBook *addressBook) 
{
    /* Logic to search contact  Display search meathod choices and gets user input */
    printf("1. Search by name\n");
    printf("2. Search by phone\n");
    printf("3. Search by email\n");
    printf("Enter your option : ");
    int option;
    scanf("%d", &option);
    if(option == 1)
    {
        int res;
        char str[50];
      
        int ind;
        printf("Enter the name: ");
        scanf(" %[^\n]", str);
   
            int count = 0;
            int match[100];      // to store the index of the contacts found
            for(int i = 0; i < addressBook->contactCount; i++)
            {
                char *ch = strstr(addressBook->contacts[i].name, str);  // to find name substring
                if(!(ch == NULL))       //if found , print the contact
                {
                    printf("\n%d %-15s %-15s %-15s\n", count + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    match[count++]=i;
                } 
            }
            if(count == 0)   // if no contacts found
            {
                printf(RED "Contact not found !\n" RESET);
                return -1;
            }

            if(count == 1)   //if only one contact found
            {
                return match[0];
            }

            //if multiple contacts found with same name go and search by number
            char str1[20];
            int res2;
            
                printf(YELLOW "\nMultiple contacts found with same name.\nSearch by phone number : " RESET);
                scanf(" %[^\n]", str1);
               

            
            for(int i = 0; i < count; i++)
            {
                if(strcmp(addressBook->contacts[match[i]].phone, str1) == 0)
                {
                    return match[i];
                }
            }
            printf(RED "No contact matched this phone number.\n" RESET);
            return -1;
        }
        
    else if(option == 2)    // searching ny name in contacts
    {
        int res2;
        
        int ind2 = -1;
        char str2[20];
        printf("Enter the phone number: ");
        scanf(" %[^\n]", str2);
        
            int flag = 0;
            for(int i = 0; i < addressBook->contactCount; i++)
            {
                char * num = strstr(addressBook->contacts[i].phone, str2);    // to find number substring
                if(!(num == NULL))
                {
                    printf("\n %-15s %-15s %-30s \n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    ind2 = i;
                    flag = 1;
                }
            }
            if(flag == 0)
            {
                printf(RED "Contact not found !\n" RESET);
                return -1;
            }
            return ind2;
        }
    

    else if(option == 3)
    {
        int res3;
        
        int ind3 = -1;
        char str3[50];
        printf("Enter the Email : ");
        scanf(" %[^\n]", str3);
        
            int flag = 0;
            for(int i = 0; i < addressBook->contactCount; i++)
            {
                char *ch = strstr(addressBook->contacts[i].email, str3);
                if(!(ch == NULL))
                {
                    printf("\n%-15s %-15s%-30s\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    ind3 = i;
                    flag = 1;
                }
            }
            if(flag == 0)
            {
                printf(RED "Contact not found !\n" RESET);
                return -1;
            }
            return ind3;
        }
        
    else
    {
        printf(RED "Error ! Choose the correct option!" RESET);
        return -1;
    }
    
}
void editContact(AddressBook *addressBook)
{
    int index = searchContact(addressBook);
    if (index == -1) 
    {
        printf(RED "No contact found to edit.\n" RESET);
        return;
    }
    char Name[50];
    char input[100];
    int option = 0;
    int res = 0;
    printf(BLUE "\nWhat do you want to edit this contact!!!!\n \n1.edit name \n2.edit phone \n3.edit email \n" RESET);
    printf("choose one option : ");
    scanf("%d", &option);
    getchar();        // clear newline after scanf
    if(option > 0 && option < 4)
    {
        if(option == 1)
        {
            do
            {
            printf(BLUE "Enter new name : " RESET);
            scanf(" %[^\n]", input);
            res = validate_name(input);
            if(res == 1)
            {
                printf(RED "Given name is  invalid \n" RESET);
            }
            } while (res  == 1);
            strcpy(addressBook->contacts[index].name, input);
            printf(GREEN "Name updated successfully.\n" RESET);
        }
        else if(option == 2)
        {
            char number[12];
            do
            {
            printf(BLUE "Enter new phone : " RESET);
            scanf(" %s", number);
            
            res =  validate_number(number);
            if(res == 1 || strlen(number) != 10)
            {
                printf(RED "Given name is  invalid \n" RESET);
            }
            } while (res  == 1 || strlen(number) != 10);
            strcpy(addressBook->contacts[index].phone, number);
            printf(GREEN "Phone number updated successfully.\n" RESET);
        }
        else if(option == 3)
        {
          do
            {
                printf(BLUE "Enter new email : " RESET);
                scanf(" %s", input);
                res = validate_email(input);
                    if(res == 1)
                    {
                        printf(RED "Given name is  invalid \n" RESET);
                    }
            } while (res  == 1);
            strcpy(addressBook->contacts[index].email, input);
            printf(GREEN "Email Updated successfully.\n" RESET);
        }
    }  
    else
    {
        printf(RED "Enter inavild option.\n" RESET);
    }  
}
void deleteContact(AddressBook *addressBook)
{
    printf(BLUE "To delete the contact.\n" RESET);
   int index = searchContact(addressBook);   // First find the contact index
    
   if(index != -1)
   { 
     for (int i = index; i < addressBook->contactCount - 1; i++)  // move every contact one position left to overwrite delete one contact
       {
            strcpy(addressBook->contacts[i].name,addressBook->contacts[i + 1].name);
            strcpy(addressBook->contacts[i].phone,addressBook->contacts[i + 1].phone);
            strcpy(addressBook->contacts[i].email,addressBook->contacts[i + 1].email);

       }
      if (index == -1) 
        {
            printf(RED "Phone number is not in the list.\n" RESET);
            return;
        }
    
        printf(BLUE "Are you delete this contact \n1.yes \n2.No \n" RESET);
        int option;
        scanf("%d", &option);
          if(option == 1)
            {
                printf(YELLOW "Yes, Delete this contect.\n" RESET);
            }
          if(option == 2)
            {
             printf(YELLOW "No, I am not deleting thi contact.\n" RESET);
             return;
            }
        addressBook->contactCount--;
        printf(GREEN "Contact deleted successfully.\n" RESET);
    }
  else
  {
    printf(RED "\n No contact found.\n" RESET);
  }
}